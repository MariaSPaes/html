// BIA - Chat de IA para orientação profissional no ABC Paulista
class BIAChatApp {
    constructor() {
        this.isOpen = false;
        this.conversationHistory = [];
        this.userProfile = null;
        this.isTyping = false;
        this.knowledgeBase = this.initializeKnowledgeBase();
        this.init();
    }

    initializeKnowledgeBase() {
        return {
            empresasABC: [
                'Braskem', 'Mercedes-Benz', 'Scania', 'Volkswagen', 'Ford', 
                'General Motors', 'Pirelli', 'Rhodia', 'Petrobras', 'Oxiteno',
                'Mahle', 'Continental', 'Bosch', 'ZF', 'Thyssenkrupp'
            ],
            cursosRecomendados: {
                'operador-producao': [
                    {
                        nome: 'Operação de Processos Petroquímicos',
                        instituicao: 'SENAI Santo André',
                        duracao: '160 horas',
                        preco: 'Gratuito',
                        descricao: 'Curso específico para operação em plantas petroquímicas'
                    },
                    {
                        nome: 'Segurança em Processos Industriais',
                        instituicao: 'SENAI São Bernardo',
                        duracao: '80 horas',
                        preco: 'R$ 320,00',
                        descricao: 'Normas de segurança para ambiente industrial'
                    }
                ],
                'manutencao-industrial': [
                    {
                        nome: 'Manutenção Preditiva e Preventiva',
                        instituicao: 'SENAI Diadema',
                        duracao: '120 horas',
                        preco: 'R$ 450,00',
                        descricao: 'Técnicas modernas de manutenção industrial'
                    },
                    {
                        nome: 'Soldagem MIG/MAG',
                        instituicao: 'SENAI São Caetano',
                        duracao: '200 horas',
                        preco: 'R$ 680,00',
                        descricao: 'Soldagem para manutenção industrial'
                    }
                ],
                'logistica': [
                    {
                        nome: 'Gestão de Estoque e Armazenagem',
                        instituicao: 'SENAI Mauá',
                        duracao: '60 horas',
                        preco: 'R$ 280,00',
                        descricao: 'Controle de estoque e organização de almoxarifado'
                    },
                    {
                        nome: 'Operação de Empilhadeira',
                        instituicao: 'SENAI Santo André',
                        duracao: '40 horas',
                        preco: 'R$ 350,00',
                        descricao: 'Habilitação para operar empilhadeiras'
                    }
                ]
            },
            dicasEntrevista: [
                'Chegue 15 minutos antes do horário marcado',
                'Vista roupas adequadas para o ambiente industrial',
                'Leve currículo atualizado e documentos organizados',
                'Pesquise sobre a empresa antes da entrevista',
                'Demonstre interesse genuíno pela vaga',
                'Seja honesto sobre suas experiências',
                'Faça perguntas sobre a função e a empresa',
                'Mantenha postura profissional e educada'
            ],
            salariosMediosABC: {
                'operador-producao': 'R$ 2.800 - R$ 3.500',
                'tecnico-manutencao': 'R$ 3.200 - R$ 4.800',
                'auxiliar-logistica': 'R$ 2.200 - R$ 2.800',
                'assistente-administrativo': 'R$ 2.000 - R$ 2.600',
                'tecnico-qualidade': 'R$ 2.900 - R$ 3.800'
            }
        };
    }

    init() {
        this.setupEventListeners();
        this.loadConversationHistory();
        this.initializeGreeting();
    }

    setupEventListeners() {
        const chatToggle = document.getElementById('chat-toggle');
        const chatClose = document.getElementById('chat-close');
        const chatSend = document.getElementById('chat-send');
        const chatInput = document.getElementById('chat-input');

        if (chatToggle) {
            chatToggle.addEventListener('click', () => this.toggleChat());
        }

        if (chatClose) {
            chatClose.addEventListener('click', () => this.closeChat());
        }

        if (chatSend) {
            chatSend.addEventListener('click', () => this.sendUserMessage());
        }

        if (chatInput) {
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendUserMessage();
                }
            });
        }

        // Quick buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('quick-btn')) {
                const message = e.target.textContent.trim();
                this.sendMessage(message, true);
            }
        });
    }

    toggleChat() {
        if (this.isOpen) {
            this.closeChat();
        } else {
            this.openChat();
        }
    }

    openChat() {
        const chatWindow = document.getElementById('chat-window');
        if (chatWindow) {
            chatWindow.classList.add('active');
            this.isOpen = true;
            this.loadUserProfile();
            this.updateQuickQuestions();
            
            // Focus no input
            setTimeout(() => {
                const chatInput = document.getElementById('chat-input');
                if (chatInput) chatInput.focus();
            }, 300);
        }
    }

    closeChat() {
        const chatWindow = document.getElementById('chat-window');
        if (chatWindow) {
            chatWindow.classList.remove('active');
            this.isOpen = false;
        }
    }

    sendUserMessage() {
        const chatInput = document.getElementById('chat-input');
        if (chatInput && chatInput.value.trim()) {
            this.sendMessage(chatInput.value.trim(), true);
            chatInput.value = '';
        }
    }

    sendMessage(message, isUser = false) {
        this.addMessageToChat(message, isUser);
        
        if (isUser) {
            this.conversationHistory.push({ role: 'user', content: message });
            this.showTypingIndicator();
            
            // Simular delay de resposta
            setTimeout(() => {
                this.hideTypingIndicator();
                this.generateResponse(message);
            }, 1500 + Math.random() * 1000);
        } else {
            this.conversationHistory.push({ role: 'assistant', content: message });
        }
        
        this.saveConversationHistory();
    }

    addMessageToChat(message, isUser = false) {
        const chatBody = document.getElementById('chat-body');
        if (!chatBody) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${isUser ? 'user-message' : 'bot-message'}`;
        
        messageDiv.innerHTML = `
            <div class="message-content">
                ${this.formatMessage(message)}
            </div>
        `;

        // Remover quick questions se existirem
        const quickQuestions = chatBody.querySelector('.quick-questions');
        if (quickQuestions && isUser) {
            quickQuestions.remove();
        }

        chatBody.appendChild(messageDiv);
        this.scrollToBottom();
    }

    formatMessage(message) {
        // Substituir **texto** por <strong>texto</strong>
        let html = message.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

        // Substituir *texto* por <em>texto</em>
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

        // Tratar listas
        const blocks = html.split('\n\n').filter(p => p.trim());
        
        let finalHtml = blocks.map(block => {
            if (block.trim().startsWith('•') || block.trim().startsWith('-')) {
                const listItems = block.split('\n').filter(line => line.trim().startsWith('•') || line.trim().startsWith('-'));
                
                if (listItems.length > 0) {
                    const ulContent = listItems.map(item => {
                        const content = item.trim().substring(1).trim();
                        return `<li>${content}</li>`;
                    }).join('');
                    
                    const preListText = block.split('\n').filter(line => !line.trim().startsWith('•') && !line.trim().startsWith('-')).join('\n').trim();
                    
                    let listBlock = '';
                    if (preListText) {
                        listBlock += `<p><strong>${preListText}</strong></p>`;
                    }
                    listBlock += `<ul>${ulContent}</ul>`;
                    
                    return listBlock;
                }
            }
            
            if (block.includes('<strong>') && block.length < 100) {
                return `<p class="section-title">${block}</p>`;
            }

            return `<p>${block}</p>`;
        }).join('');

        finalHtml = finalHtml.replace(/\n/g, '<br>');

        return finalHtml;
    }

    showTypingIndicator() {
        const chatBody = document.getElementById('chat-body');
        if (!chatBody) return;

        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message bot-message typing-indicator';
        typingDiv.innerHTML = `
            <div class="message-content">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <span class="typing-text">BIA está analisando...</span>
            </div>
        `;

        chatBody.appendChild(typingDiv);
        this.scrollToBottom();
        this.isTyping = true;
    }

    hideTypingIndicator() {
        const typingIndicator = document.querySelector('.typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
        this.isTyping = false;
    }

    generateResponse(userMessage) {
        const message = userMessage.toLowerCase();
        let response = '';

        // Análise de intenção baseada em palavras-chave
        if (this.containsKeywords(message, ['curso', 'cursos', 'aprimorar', 'estudar', 'capacitação', 'qualificação'])) {
            response = this.generateCourseRecommendation();
        } else if (this.containsKeywords(message, ['vaga', 'vagas', 'emprego', 'trabalho', 'oportunidade'])) {
            response = this.generateJobRecommendation();
        } else if (this.containsKeywords(message, ['entrevista', 'dicas', 'preparar', 'processo seletivo'])) {
            response = this.generateInterviewTips();
        } else if (this.containsKeywords(message, ['salário', 'salario', 'quanto ganha', 'remuneração'])) {
            response = this.generateSalaryInfo();
        } else if (this.containsKeywords(message, ['currículo', 'curriculo', 'cv', 'melhorar perfil'])) {
            response = this.generateCurriculumTips();
        } else if (this.containsKeywords(message, ['empresa', 'empresas', 'abc', 'região'])) {
            response = this.generateCompanyInfo();
        } else {
            response = this.generateGeneralResponse();
        }

        this.sendMessage(response, false);
        this.updateQuickQuestions();
    }

    containsKeywords(text, keywords) {
        return keywords.some(keyword => text.includes(keyword));
    }

    generateCourseRecommendation() {
        this.loadUserProfile();
        
        let response = `**Recomendações de Cursos Personalizadas**\n\n`;
        
        if (this.userProfile && this.userProfile.programa) {
            const cursos = this.knowledgeBase.cursosRecomendados[this.userProfile.programa] || [];
            
            if (cursos.length > 0) {
                response += `**Para sua área (${this.userProfile.programa}):**\n\n`;
                cursos.forEach(curso => {
                    response += `**${curso.nome}**\n`;
                    response += `• Instituição: ${curso.instituicao}\n`;
                    response += `• Duração: ${curso.duracao}\n`;
                    response += `• Investimento: ${curso.preco}\n`;
                    response += `• Descrição: ${curso.descricao}\n\n`;
                });
            }
        } else {
            response += `**Cursos Gerais Recomendados:**\n\n`;
            response += `• **NR10** - Segurança em Instalações Elétricas\n`;
            response += `• **NR35** - Trabalho em Altura\n`;
            response += `• **Primeiros Socorros** - Essencial para qualquer área\n`;
            response += `• **Excel Avançado** - Ferramenta fundamental\n\n`;
        }
        
        response += `**Dica:** Complete seu perfil para recomendações mais específicas!`;
        
        return response;
    }

    generateJobRecommendation() {
        let response = `**Vagas em Destaque no ABC Paulista**\n\n`;
        
        response += `**Operador de Produção - Braskem**\n`;
        response += `• Salário: R$ 3.200 + benefícios\n`;
        response += `• Local: Santo André\n`;
        response += `• Requisito: Ensino médio completo\n\n`;
        
        response += `**Técnico de Manutenção - Mercedes-Benz**\n`;
        response += `• Salário: R$ 4.500 + benefícios\n`;
        response += `• Local: São Bernardo do Campo\n`;
        response += `• Requisito: Curso técnico\n\n`;
        
        response += `**Auxiliar de Logística - Continental**\n`;
        response += `• Salário: R$ 2.600 + benefícios\n`;
        response += `• Local: Diadema\n`;
        response += `• Requisito: Curso de Metrologia\n\n`;
        
        response += `**Dica:** Clique em "VAGAS" no menu superior para ver todas as oportunidades.`;
        
        return response;
    }

    generateInterviewTips() {
        let response = `**Dicas Essenciais para Entrevistas**\n\n`;
        
        response += `**Antes da Entrevista**\n`;
        this.knowledgeBase.dicasEntrevista.slice(0, 4).forEach(dica => {
            response += `• ${dica}\n`;
        });
        response += `\n`;
        
        response += `**Durante a Entrevista**\n`;
        this.knowledgeBase.dicasEntrevista.slice(4, 8).forEach(dica => {
            response += `• ${dica}\n`;
        });
        
        return response;
    }

    generateSalaryInfo() {
        let response = `**Salários Médios no ABC Paulista**\n\n`;
        
        response += `• Operador de Produção: ${this.knowledgeBase.salariosMediosABC['operador-producao']}\n`;
        response += `• Técnico de Manutenção: ${this.knowledgeBase.salariosMediosABC['tecnico-manutencao']}\n`;
        response += `• Auxiliar de Logística: ${this.knowledgeBase.salariosMediosABC['auxiliar-logistica']}\n`;
        response += `• Assistente Administrativo: ${this.knowledgeBase.salariosMediosABC['assistente-administrativo']}\n`;
        response += `• Técnico de Qualidade: ${this.knowledgeBase.salariosMediosABC['tecnico-qualidade']}\n\n`;
        
        response += `**Dica:** Nunca revele sua pretensão salarial antes de saber a faixa da empresa.`;
        
        return response;
    }

    generateCurriculumTips() {
        let response = `**Dicas para um Currículo Vencedor**\n\n`;
        
        response += `**Estrutura básica**\n`;
        response += `• Dados pessoais (nome, contato, cidade)\n`;
        response += `• Objetivo profissional claro\n`;
        response += `• Experiência profissional\n`;
        response += `• Formação acadêmica e cursos\n`;
        response += `• Competências e idiomas\n\n`;
        
        response += `**Diferenciais para o ABC**\n`;
        response += `• Certificações de segurança (NR10, NR35)\n`;
        response += `• Experiência com trabalho em turnos\n`;
        response += `• Conhecimento em processos industriais\n`;
        
        return response;
    }

    generateCompanyInfo() {
        let response = `**Principais Empresas do ABC Paulista**\n\n`;
        
        response += `**Setor Petroquímico**\n`;
        response += `• **Braskem** - Líder em petroquímicos\n`;
        response += `• **Oxiteno** - Especialidades químicas\n`;
        response += `• **Rhodia** - Química avançada\n\n`;
        
        response += `**Setor Automotivo**\n`;
        response += `• **Mercedes-Benz** - Veículos comerciais\n`;
        response += `• **Scania** - Caminhões e ônibus\n`;
        response += `• **Volkswagen** - Automóveis\n\n`;
        
        response += `**Dica:** Pesquise sobre a cultura da empresa antes de se candidatar.`;
        
        return response;
    }

    generateGeneralResponse() {
        this.loadUserProfile();
        
        if (!this.userProfile || !this.userProfile.nome) {
            return `Olá! Sou a BIA, sua mentora de carreira do ABC Paulista.\n\n**Complete seu perfil** na seção "MEU PERFIL" para que eu possa te dar as melhores recomendações!\n\nComo posso te ajudar hoje?`;
        } else {
            return `Olá ${this.userProfile.nome}! Estou aqui para te ajudar com:\n\n• **Busca de vagas** na região\n• **Recomendações de cursos**\n• **Dicas de entrevista**\n• **Orientações de carreira**\n\nComo posso te ajudar hoje?`;
        }
    }

    updateQuickQuestions() {
        const chatBody = document.getElementById('chat-body');
        if (!chatBody) return;

        // Remover quick questions existentes
        const existingQuestions = chatBody.querySelector('.quick-questions');
        if (existingQuestions) {
            existingQuestions.remove();
        }

        // Adicionar novas quick questions
        const quickQuestions = document.createElement('div');
        quickQuestions.className = 'quick-questions';
        
        const questions = this.getContextualQuestions();
        
        quickQuestions.innerHTML = questions.map(q => 
            `<button class="quick-btn">${q}</button>`
        ).join('');

        chatBody.appendChild(quickQuestions);
        this.scrollToBottom();
    }

    getContextualQuestions() {
        this.loadUserProfile();
        
        if (!this.userProfile || !this.userProfile.nome) {
            return [
                'Como criar meu perfil?',
                'Empresas do ABC Paulista',
                'Salários na região',
                'Como usar a plataforma'
            ];
        }

        return [
            'Vagas disponíveis no ABC',
            'Cursos recomendados',
            'Dicas de entrevista',
            'Como melhorar meu currículo'
        ];
    }

    initializeGreeting() {
        // Adicionar mensagem de boas-vindas apenas se não houver histórico
        if (this.conversationHistory.length === 0) {
            const greeting = `Olá! Sou a BIA, sua mentora de carreira do ABC Paulista.\n\nEstou aqui para te ajudar a encontrar emprego na região.\n\nComo posso te ajudar hoje?`;
            
            setTimeout(() => {
                this.sendMessage(greeting, false);
            }, 1000);
        }
    }

    loadUserProfile() {
        const saved = localStorage.getItem('skynet-user-profile');
        this.userProfile = saved ? JSON.parse(saved) : null;
    }

    loadConversationHistory() {
        const saved = localStorage.getItem('skynet-chat-history');
        this.conversationHistory = saved ? JSON.parse(saved) : [];
        
        // Recriar mensagens no chat
        this.conversationHistory.forEach(msg => {
            this.addMessageToChat(msg.content, msg.role === 'user');
        });
    }

    saveConversationHistory() {
        localStorage.setItem('skynet-chat-history', JSON.stringify(this.conversationHistory));
    }

    scrollToBottom() {
        const chatBody = document.getElementById('chat-body');
        if (chatBody) {
            setTimeout(() => {
                chatBody.scrollTop = chatBody.scrollHeight;
            }, 100);
        }
    }
}

// Função global para abrir chat com recomendação de cursos
window.sendQuickMessage = (message) => {
    if (window.chatApp) {
        window.chatApp.sendMessage(message, true);
    }
};

// Inicializar chat
document.addEventListener('DOMContentLoaded', () => {
    window.chatApp = new BIAChatApp();
});

// Estilos específicos do chat
const chatStyles = `
<style>
.typing-dots {
    display: inline-flex;
    gap: 4px;
    align-items: center;
}

.typing-dots span {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--primary-blue);
    animation: typing 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(1) { animation-delay: -0.32s; }
.typing-dots span:nth-child(2) { animation-delay: -0.16s; }

@keyframes typing {
    0%, 80%, 100% { transform: scale(0); }
    40% { transform: scale(1); }
}

.typing-text {
    margin-left: 10px;
    font-style: italic;
    color: var(--gray);
}

.message-content ul {
    margin: 1rem 0;
    padding-left: 1.5rem;
}

.message-content li {
    margin: 0.6rem 0;
    line-height: 1.6;
}

.message-content strong {
    color: var(--primary-blue);
    font-weight: 600;
}

.section-title {
    color: var(--primary-blue) !important;
    font-weight: 600 !important;
    font-size: 1.1rem !important;
    margin: 1.5rem 0 0.8rem 0;
}
</style>
`;

// Inserir estilos no DOM
document.addEventListener('DOMContentLoaded', () => {
    const styleElement = document.createElement('style');
    styleElement.textContent = chatStyles;
    document.head.appendChild(styleElement);
});
