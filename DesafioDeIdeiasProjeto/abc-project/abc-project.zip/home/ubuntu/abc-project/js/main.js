// JavaScript principal do SKYNET - ABC Paulista
document.addEventListener('DOMContentLoaded', function() {
    
    // Navegação entre páginas
    const navLinks = document.querySelectorAll('.nav-link');
    const pages = document.querySelectorAll('.page');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active de todos os links
            navLinks.forEach(l => l.classList.remove('active'));
            // Adiciona active ao link clicado
            this.classList.add('active');
            
            // Esconde todas as páginas
            pages.forEach(page => page.classList.remove('active'));
            
            // Mostra a página correspondente
            const targetPage = this.getAttribute('data-page');
            const targetElement = document.getElementById(targetPage);
            if (targetElement) {
                targetElement.classList.add('active');
            }
        });
    });
    
    // Menu de acessibilidade
    const accessibilityBtn = document.querySelector('.accessibility-btn');
    const accessibilityMenu = document.getElementById('accessibility-menu');
    
    if (accessibilityBtn && accessibilityMenu) {
        accessibilityBtn.addEventListener('click', function() {
            accessibilityMenu.classList.toggle('active');
        });
        
        // Fechar menu ao clicar fora
        document.addEventListener('click', function(e) {
            if (!accessibilityBtn.contains(e.target) && !accessibilityMenu.contains(e.target)) {
                accessibilityMenu.classList.remove('active');
            }
        });
    }
    
    // CORREÇÃO: Funcionalidades de acessibilidade
    
    // Alto contraste
    const highContrastToggle = document.getElementById('high-contrast-toggle');
    if (highContrastToggle) {
        highContrastToggle.addEventListener('click', function() {
            document.body.classList.toggle('high-contrast');
            localStorage.setItem('high-contrast', document.body.classList.contains('high-contrast'));
        });
        
        // Carregar preferência salva
        if (localStorage.getItem('high-contrast') === 'true') {
            document.body.classList.add('high-contrast');
        }
    }
    
    // Aumentar fonte
    const fontSizeIncrease = document.getElementById('font-size-increase');
    if (fontSizeIncrease) {
        fontSizeIncrease.addEventListener('click', function() {
            document.body.classList.remove('font-small');
            document.body.classList.add('font-large');
            localStorage.setItem('font-size', 'large');
        });
    }
    
    // Diminuir fonte
    const fontSizeDecrease = document.getElementById('font-size-decrease');
    if (fontSizeDecrease) {
        fontSizeDecrease.addEventListener('click', function() {
            document.body.classList.remove('font-large');
            document.body.classList.add('font-small');
            localStorage.setItem('font-size', 'small');
        });
    }
    
    // CORREÇÃO: VLibras funcional
    const vlibrasToggle = document.getElementById('vlibras-toggle');
    if (vlibrasToggle) {
        vlibrasToggle.addEventListener('click', function() {
            // Ativar/desativar VLibras
            const vlibrasWidget = document.querySelector('[vw]');
            if (vlibrasWidget) {
                const isActive = vlibrasWidget.style.display !== 'none';
                vlibrasWidget.style.display = isActive ? 'none' : 'block';
                
                // Feedback visual
                this.style.background = isActive ? 'var(--light-gray)' : 'var(--primary-blue)';
                this.style.color = isActive ? 'var(--black)' : 'var(--white)';
            }
        });
    }
    
    // CORREÇÃO: Leitor de tela funcional
    const screenReaderToggle = document.getElementById('screen-reader-toggle');
    let speechSynthesis = window.speechSynthesis;
    let isReaderActive = false;
    
    if (screenReaderToggle) {
        screenReaderToggle.addEventListener('click', function() {
            isReaderActive = !isReaderActive;
            
            if (isReaderActive) {
                this.style.background = 'var(--primary-blue)';
                this.style.color = 'var(--white)';
                
                // Ativar leitor de tela
                document.addEventListener('mouseover', readElementOnHover);
                document.addEventListener('focus', readElementOnFocus, true);
                
                // Anunciar ativação
                speak('Leitor de tela ativado. Passe o mouse sobre os elementos para ouvi-los.');
            } else {
                this.style.background = 'var(--light-gray)';
                this.style.color = 'var(--black)';
                
                // Desativar leitor de tela
                document.removeEventListener('mouseover', readElementOnHover);
                document.removeEventListener('focus', readElementOnFocus, true);
                
                // Parar qualquer leitura em andamento
                speechSynthesis.cancel();
                
                speak('Leitor de tela desativado.');
            }
        });
    }
    
    function readElementOnHover(e) {
        if (!isReaderActive) return;
        
        const element = e.target;
        let textToRead = '';
        
        // Determinar o que ler baseado no tipo de elemento
        if (element.tagName === 'BUTTON') {
            textToRead = element.textContent || element.getAttribute('aria-label') || 'Botão';
        } else if (element.tagName === 'A') {
            textToRead = element.textContent || element.getAttribute('aria-label') || 'Link';
        } else if (element.tagName === 'INPUT') {
            const label = document.querySelector(`label[for="${element.id}"]`);
            textToRead = label ? label.textContent : element.placeholder || 'Campo de entrada';
        } else if (element.tagName === 'H1' || element.tagName === 'H2' || element.tagName === 'H3') {
            textToRead = 'Título: ' + element.textContent;
        } else if (element.classList.contains('nav-link')) {
            textToRead = 'Menu: ' + element.textContent;
        }
        
        if (textToRead.trim()) {
            speak(textToRead);
        }
    }
    
    function readElementOnFocus(e) {
        if (!isReaderActive) return;
        readElementOnHover(e);
    }
    
    function speak(text) {
        speechSynthesis.cancel(); // Parar leitura anterior
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pt-BR';
        utterance.rate = 0.8;
        utterance.pitch = 1;
        
        speechSynthesis.speak(utterance);
    }
    
    // Carregar preferências de fonte salvas
    const savedFontSize = localStorage.getItem('font-size');
    if (savedFontSize === 'large') {
        document.body.classList.add('font-large');
    } else if (savedFontSize === 'small') {
        document.body.classList.add('font-small');
    }
    
    // Botões de ação
    const candidateBtn = document.querySelector('[data-action="candidate-flow"]');
    const employerBtn = document.querySelector('[data-action="employer-flow"]');
    const showPageBtns = document.querySelectorAll('[data-action="show-page"]');
    
    if (candidateBtn) {
        candidateBtn.addEventListener('click', function() {
            // Navegar para perfil do candidato
            navLinks.forEach(l => l.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));
            
            const perfilLink = document.querySelector('[data-page="meu-perfil"]');
            const perfilPage = document.getElementById('perfil-candidato');
            
            if (perfilLink && perfilPage) {
                perfilLink.classList.add('active');
                perfilPage.classList.add('active');
            }
        });
    }
    
    if (employerBtn) {
        employerBtn.addEventListener('click', function() {
            // Navegar para informações da vaga
            pages.forEach(page => page.classList.remove('active'));
            const vagaPage = document.getElementById('informacoes-vaga');
            if (vagaPage) {
                vagaPage.classList.add('active');
            }
        });
    }
    
    showPageBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const pageId = this.getAttribute('data-page-id');
            
            navLinks.forEach(l => l.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));
            
            const targetLink = document.querySelector(`[data-page="${pageId}"]`);
            const targetPage = document.getElementById(pageId);
            
            if (targetLink && targetPage) {
                targetLink.classList.add('active');
                targetPage.classList.add('active');
            }
        });
    });
    
    // Perfil do candidato - Progresso
    const formInputs = document.querySelectorAll('#perfil-candidato input, #perfil-candidato select');
    const checkboxes = document.querySelectorAll('#perfil-candidato input[type="checkbox"]');
    const progressFill = document.getElementById('progress-fill');
    
    function updateProgress() {
        let filledFields = 0;
        let totalFields = 4; // nome, estado, cidade, programa
        
        formInputs.forEach(input => {
            if (input.type !== 'checkbox' && input.value.trim() !== '') {
                filledFields++;
            }
        });
        
        const checkedBoxes = document.querySelectorAll('#perfil-candidato input[type="checkbox"]:checked').length;
        const competenciasProgress = Math.min(checkedBoxes / 5, 1); // Máximo 5 competências para 100%
        
        const totalProgress = ((filledFields / totalFields) * 80) + (competenciasProgress * 20);
        
        if (progressFill) {
            progressFill.style.width = totalProgress + '%';
        }
    }
    
    formInputs.forEach(input => {
        input.addEventListener('input', updateProgress);
        input.addEventListener('change', updateProgress);
    });
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateProgress);
    });
    
    // Salvar perfil
    const saveProfileBtn = document.querySelector('[data-action="save-profile"]');
    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', function() {
            const profileData = {
                nome: document.getElementById('nome')?.value || '',
                estado: document.getElementById('estado')?.value || '',
                cidade: document.getElementById('cidade')?.value || '',
                programa: document.getElementById('programa')?.value || '',
                competencias: Array.from(document.querySelectorAll('#perfil-candidato input[type="checkbox"]:checked')).map(cb => cb.value)
            };
            
            localStorage.setItem('skynet-user-profile', JSON.stringify(profileData));
            
            // Feedback visual
            this.innerHTML = '<i class="fas fa-check"></i> Perfil Salvo!';
            this.style.background = 'var(--green)';
            
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-check"></i> Salvar seu perfil';
                this.style.background = '';
            }, 2000);
        });
    }
    
    // CORREÇÃO: Botão de melhoria do perfil que abre o chat BIA
    const improvementBtn = document.querySelector('[data-action="open-chat-recommendation"]');
    if (improvementBtn) {
        improvementBtn.addEventListener('click', function() {
            // Abrir chat BIA
            const chatToggle = document.getElementById('chat-toggle');
            if (chatToggle) {
                chatToggle.click();
            }
            
            // Enviar mensagem automática após um delay
            setTimeout(() => {
                if (window.chatApp) {
                    window.chatApp.sendMessage('Gostaria de recomendações de cursos para aprimorar meu perfil profissional', true);
                }
            }, 1000);
        });
    }
    
    // FAQ Toggle
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        if (question) {
            question.addEventListener('click', function() {
                const isActive = item.classList.contains('active');
                
                // Fechar todos os outros FAQs
                faqItems.forEach(otherItem => {
                    otherItem.classList.remove('active');
                });
                
                // Toggle do item atual
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        }
    });
    
    // Menu mobile
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Inicializar progresso
    updateProgress();
});

// Função global para envio rápido de mensagens no chat
window.sendQuickMessage = function(message) {
    if (window.chatApp) {
        window.chatApp.sendMessage(message, true);
    }
};
